var COMBO_ESCONDIDO = new Array();
var COMBO_NET_FOCO;

/*********************************\
|*  Fun��o combo_net
|*
\*********************************/

function combo_net(nome, exibe_combo) {

	var TEMPO = 50;
	
	if( exibe_combo == 1 ) {
		
		tam_top = centraliza_janela('top',nome) // centraliza a janela do combo
		tam_left = centraliza_janela('left',nome) // centraliza a janela do combo
		
		$('div_'+nome).style.top=tam_top+'px';
		$('div_'+nome).style.left=tam_left+'px';
		
		$('div_'+nome).style.display='block';
		$('div_'+nome).style.zIndex=100;
		
		return;
	}

	esconde_combo();
	
	$('html').style.overflow='hidden';
	// trava a janela para nao criar barra de rolagem
	
	e = $('combo_net_trava');
	if( e == null ) {
		comp = "<div id=combo_net_trava class=combo_net_trava>&nbsp;</div>";
		document.body.innerHTML += comp;
	} // cria o div que trava a janela ao fundo, caso nao exista
	
	$('combo_net_trava').style.top=0;
	$('combo_net_trava').style.left=0;
	$('combo_net_trava').style.zIndex=10;
	$('combo_net_trava').style.display='block';
	$('combo_net_trava').style.height=screen.availHeight+'px';
	$('combo_net_trava').style.width='1%';
	// seta o div atras para travar a janela

	COMBO_NET_FOCO = nome;

	
	for(i=10, j=1; i<=150; i+=10, j++) {
		
		setTimeout("document.getElementById('combo_net_trava').style.width='"+i+"%'",TEMPO*j);
		
	} // chama a funcao que faz crescer a div de travamento

	setTimeout("combo_net('"+nome+"',1)",TEMPO*j);
	// exibe a janela do combo apos a div ter sido completada
	
	setTimeout("foco_combo_net('"+nome+"')",(TEMPO*(j+10)));
	
}

function foco_combo_net(nome) {

	var t = window.frames['frame_'+nome].document.forms[0].elements.length;
	
	for(i=0; i!=t; i++) {
		
		if( window.frames['frame_'+nome].document.forms[0].elements[i].type == 'text' ) {
			window.frames['frame_'+nome].document.forms[0].elements[i].focus();
			break;
		}
	}
	
}


function fecha_combo_net_teclado() {

	var whichCode = (window.Event) ? event.which : event.keyCode;

	if( whichCode == 27 ) 
		fecha_combo_net();

}

function fecha_combo_net() {

	
	nome = window.parent.COMBO_NET_FOCO;
	// acha qual janela esta com o foco
	
	window.parent.$('combo_net_trava').style.display='none';
	// esconde o div que trava a janela

	exibe_combo();
	// exibe os comos que estavam escondidos por causa do div que trava a janela
	
	window.parent.$('div_'+nome).style.display='none';
	// esconde a janela
	
	window.parent.$('nome_'+nome).focus();
	// da foco ao campo
	
}


function seleciona_combo_net(id,nome) {

	janela = window.parent.COMBO_NET_FOCO;
	// acha qual janela esta com o foco

	window.parent.$(janela).value=id;
	window.parent.$('nome_'+janela).value=nome;
	window.parent.$('orig_'+janela).value=nome;
	
	fecha_combo_net();
	
}


function combo_net_teclado(nome) {

	var whichCode = (window.Event) ? event.which : event.keyCode;

	
	$('nome_'+nome).value = $('orig_'+nome).value;
	if( whichCode == 32 ) 
		combo_net(nome);


}

function exibe_combo() {

	var t_campos = parent.COMBO_ESCONDIDO.length;

	if( t_campos > 0 ) {
		
		for(i=0; i!=t_campos; i++) {
			
			form = parent.COMBO_ESCONDIDO[i].form;
			id = parent.COMBO_ESCONDIDO[i].id;
			
			window.parent.document.forms[form].elements[id].style.visibility='';	
			
		}
	}
}

function esconde_combo() {

	t_form = document.forms.length;
	
	for(i=0; i!=t_form; i++) {
		
		t_elementos = document.forms[i].elements.length;
		
		for(j=0; j!=t_elementos; j++) {
			
			if(	document.forms[i].elements[j].type == 'select-one' ||  
				document.forms[i].elements[j].type == 'submit' 	) {
				
				document.forms[i].elements[j].style.visibility='hidden';
				COMBO_ESCONDIDO[COMBO_ESCONDIDO.length] = { form:i, id:j};
				
			} // se for um combo
		}
	} // varre os formularios procurando por combos para sumir
}


/**************************************************\
|* centraliza_janela()
|*
|* funcao para calcular a posicao centralizada da janela
|* tipo eh "top" ou "Left" e o nome eh o nome da janela (combo_net)
|*
\**************************************************/

function centraliza_janela(tipo,nome) {

	// iframe1 porque sempre sera aberto e todos os outros iframes terao o mesmo tamanho, assim da pra saber o tamanho total da janela

	if( tipo == 'left' ) {
		
		tam_total = window.parent.$('iframe1').style.width;
		t_tam = window.parent.$('iframe1').style.width.length-2;
		total_janela = window.parent.$('iframe1').style.width.substr(0,t_tam);
		
		$('frame_'+nome).width = (total_janela-80)+'px';
		// seta o tamanho da janela
		
		total_combo = $('frame_'+nome).width;
		tam_left = (total_janela/2) - (total_combo/2);
		// calcula o tamanho left
		
		return tam_left;
		
	} else {	
		
		tam_total = window.parent.$('iframe1').style.height;
		t_tam = window.parent.$('iframe1').style.height.length-2;
		total_janela = window.parent.$('iframe1').style.height.substr(0,t_tam);
		
		$('frame_'+nome).height = (total_janela-50)+'px';
		// seta o tamanho da janela
		
		total_combo = $('frame_'+nome).height;
		tam_top = (total_janela/2) - (total_combo/2);
		
		return tam_top;
	}
	
}

